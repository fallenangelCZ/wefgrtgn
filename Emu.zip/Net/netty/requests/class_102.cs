﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Ow.Net.netty.requests
{
    class class_102
    {
        public const int ID = 21931;

        public int method_1330()
        {
            return ID;
        }

        public int method_1260()
        {
            return 0;
        }

        public void readCommand(byte[] bytes)
        {
            var parser = new ByteParser(bytes);

            var param1 = parser.readShort();

        }
    }
}
