﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class QuestConditionModule
    {
        public static short ID = 23685;

        public const short DAMAGE = 7;
        public const short AVOID_DAMAGE = 8;
        public const short WEB = 46;
        public const short BILMIYORUM1 = 73;
        public const short VISIT_MAP_ASSET = 71;
        public const short PUT_ITEM_IN_SLOT_BAR = 66;
        public const short USE_ORE_UPDATE = 68;
        public const short AVOID_KILL_NPCS = 34;
        public const short STAY_AWAY = 43;
        public const short COLLECT_LOOT = 63;
        public const short MISCELLANEOUS = 19;
        public const short BILMIYORUM2 = 67;
        public const short MAP_DIVERSE = 17;
        public const short COORDINATES = 11;
        public const short LEVEL = 50;
        public const short BILMIYORUM3 = 25;
        public const short VISIT_MAP = 31;
        public const short BILMIYORUM4 = 51;
        public const short KILL_NPCS = 27;
        public const short REAL_TIME_HASTE = 60;
        public const short FINISH_STARTER_GATE = 64;
        public const short PREVENT = 38;
        public const short STEADINESS = 41;
        public const short AVOID_JUMP = 40;
        public const short QUICK_BUY = 54;
        public const short FUEL_SHORTAGE = 14;
        public const short AMMUNITION = 20;
        public const short BILMIYORUM5 = 26;
        public const short COUNTDOWN = 4;
        public const short GAIN_INFLUENCE = 76;
        public const short DISTANCE = 12;
        public const short BILMIYORUM6 = 53;
        public const short JUMP = 39;
        public const short ACTIVATE_MAP_ASSET_TYPE = 70;
        public const short MAP = 16;
        public const short DAMAGE_NPCS = 29;
        public const short AVOID_DAMAGE_NPCS = 36;
        public const short AVOID_DEATH = 10;
        public const short FINISH_GALAXY_GATE = 75;
        public const short MULTIPLIER = 42;
        public const short BILMIYORUM7 = 0;
        public const short SPEND_AMMUNITION = 22;
        public const short IN_CLAN = 62;
        public const short RESTRICT_AMMUNITION_KILL_PLAYER = 57;
        public const short VISIT_QUEST_GIVER = 59;
        public const short AVOID_KILL_NPC = 33;
        public const short BILMIYORUM8 = 58;
        public const short KILL_NPC = 6;
        public const short KILL_ANY = 45;
        public const short EMPTY = 18;
        public const short REFINE_ORE = 65;
        public const short IN_GROUP = 44;
        public const short SALVAGE = 23;
        public const short CLIENT = 47;
        public const short HASTE = 2;
        public const short SAVE_AMMUNITION = 21;
        public const short BEACON_TAKEOVER = 74;
        public const short STEAL = 24;
        public const short AVOID_DAMAGE_PLAYERS = 37;
        public const short VISIT_JUMP_GATE_TO_MAP_TYPE = 69;
        public const short DAMAGE_PLAYERS = 30;
        public const short CARGO = 48;
        public const short UPDATE_SKYLAB_TO_LEVEL = 72;
        public const short ENDURANCE = 3;
        public const short TAKE_DAMAGE = 9;
        public const short TIMER = 1;
        public const short DIE = 32;
        public const short BILMIYORUM9 = 61;
        public const short KILL_PLAYERS = 28;
        public const short COLLECT_BONUS_BOX = 52;
        public const short TRAVEL = 13;
        public const short RESTRICT_AMMUNITION_KILL_NPC = 56;
        public const short COLLECT = 5;
        public const short AVOID_KILL_PLAYERS = 35;
        public const short ENTER_GROUP = 55;
        public const short PROXIMITY = 15;
        public const short SELL_ORE = 49;

        public List<QuestConditionModule> subConditions;
        public QuestConditionStateModule state;
        public List<String> bilinmeyen;
        public int id = 0;
        public short type = 0;
        public short displayType = 0;
        public double targetValue = 0;
        public bool mandatory = false;

        public QuestConditionModule(List<QuestConditionModule> subConditions, QuestConditionStateModule state, List<string> bilinmeyen, int id, short type, short displayType, double targetValue, bool mandatory)
        {
            this.subConditions = subConditions;
            this.state = state;
            this.bilinmeyen = bilinmeyen;
            this.id = id;
            this.type = type;
            this.displayType = displayType;
            this.targetValue = targetValue;
            this.mandatory = mandatory;
        }

        public static byte[] write(List<QuestConditionModule> subConditions, QuestConditionStateModule state, List<String> bilinmeyen, int id = 0, short type = 0, short displayType = 0, double targetValue = 0, bool mandatory = false)
        { 
            ByteArray param1 = new ByteArray(ID);

            param1.writeInt(subConditions.Count);

            foreach (QuestConditionModule item in subConditions)
            {
                QuestConditionModule.write(subConditions, state, bilinmeyen);
            }

            QuestConditionStateModule.write(state.currentValue, state.completed, state.active);

            param1.writeInt(bilinmeyen.Count);

            foreach (var item in bilinmeyen)
            {
                param1.writeUTF(item);
            }

            param1.writeInt(id >> 12 | id << 20);
            param1.writeShort(type);
            param1.writeShort(displayType);
            param1.writeDouble(targetValue);
            param1.writeBoolean(mandatory);

            return param1.ToByteArray();
        }
    }
}
