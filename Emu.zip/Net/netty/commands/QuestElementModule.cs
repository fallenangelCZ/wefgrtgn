﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class QuestElementModule
    {
        public static short ID = 10024;

        public QuestCaseModule questCase;
        public QuestConditionModule condition;

        public QuestElementModule(QuestCaseModule param1, QuestConditionModule param2)
        {
            this.questCase = param1;
            this.condition = param2;
        }

        public static byte[] write(QuestCaseModule questCase, QuestConditionModule param2)
        {
            ByteArray param1 = new ByteArray(ID);

            QuestCaseModule.write(questCase.id, questCase.active, questCase.mandatory, questCase.ordered, questCase.mandatoryCount, questCase.modifier);

            param1.writeShort(-3758);

            QuestConditionModule.write(param2.subConditions, param2.state, param2.bilinmeyen, param2.id, param2.type, param2.displayType, param2.targetValue, param2.mandatory);

            return param1.ToByteArray();
        }
    }
}
