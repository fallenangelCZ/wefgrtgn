﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class QuestIconModule
    {
        public static short ID = 2820;

        public const short KILL = 0;
        public const short COLLECT = 1;
        public const short DISCOVER = 2;
        public const short PVP = 3;
        public const short TIME = 4;
        public const short SUMMERGAMES3 = 5;
        public const short WINTERGAMES09 = 6;
        public const short HALLOWEEN2012 = 7;

        public short icon = 0;
        public QuestIconModule(short param1)
        {
            this.icon = param1;
        }

        public static byte[] write(short icon)
        {
            ByteArray param1 = new ByteArray(ID);
            param1.writeShort(22039);

            param1.writeShort(icon);


            return param1.ToByteArray();
        }
    }
}
