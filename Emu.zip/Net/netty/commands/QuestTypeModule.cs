﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class QuestTypeModule
    {
        public static short ID = 11392;

        public const short UNDEFINED = 0;
        public const short STARTER = 1;
        public const short MISSION = 2;
        public const short DAILY = 3;
        public const short CHALLENGE = 4;
        public const short EVENT = 5;


        public short type = 0;

        public QuestTypeModule(short type)
        {
            this.type = type;
        }


        public static byte[] write(short type)
        {
            ByteArray param1 = new ByteArray(ID);

            param1.writeShort(type);

            return param1.ToByteArray();
        }
    }
}
