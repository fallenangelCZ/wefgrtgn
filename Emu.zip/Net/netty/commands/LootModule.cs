﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class LootModule
    {
        public static short ID = 31673;

        public String lootId = "";
        public int amount = 0;

        public LootModule(String param1, int param2)
        {
            this.lootId = param1;
            this.amount = param2;
        }

        public static byte[] write(String lootId, int amount)
        {
            ByteArray param1 = new ByteArray(ID);

            param1.writeUTF(lootId);
            param1.writeInt(amount >> 3 | amount << 29);

            return param1.ToByteArray();
        }
    }
}
