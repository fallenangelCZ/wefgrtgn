﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class QuestConditionStateModule
    {
        public static short ID = 8820;

        public double currentValue;
        public bool completed;
        public bool active;

        public QuestConditionStateModule(double currentValue, bool completed, bool active)
        {
            this.currentValue = currentValue;
            this.completed = completed;
            this.active = active;
        }

        public static byte[] write(double currentValue, bool completed, bool active)
        {
            ByteArray arrays = new ByteArray(ID);

            arrays.writeDouble(currentValue);
            arrays.writeBoolean(completed);
            arrays.writeBoolean(active);


            return arrays.ToByteArray();
        }
    }
}
