﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class QuestCaseModule
    {
        public static short ID = 16029;

        public int id = 0;
        public bool active = false;
        public bool mandatory = false;
        public bool ordered = false;
        public int mandatoryCount = 0;
        public List<QuestElementModule> modifier;

        public QuestCaseModule(int id, bool active, bool mandatory, bool ordered, int mandatoryCount, List<QuestElementModule> modifier)
        {
            this.id = id;
            this.active = active;
            this.mandatory = mandatory;
            this.ordered = ordered;
            this.mandatoryCount = mandatoryCount;
            this.modifier = modifier;
        }

        public static byte[] write(int id, bool active, bool mandatory, bool ordered, int mandatoryCount, List<QuestElementModule> modifier)
        {
            ByteArray arrays = new ByteArray(ID);

            arrays.writeBoolean(mandatory);

            arrays.writeInt(id >> 2 | id << 30);

            arrays.writeBoolean(ordered);

            arrays.writeShort(11608);

            arrays.writeBoolean(active);

            arrays.writeShort(25588);

            arrays.writeInt(modifier.Count);

            foreach (var item in modifier)
            {
                QuestElementModule.write(item.questCase, item.condition);
            }

            arrays.writeInt(mandatoryCount >> 2 | mandatoryCount << 30);

            return arrays.ToByteArray();
        }
    }
}
