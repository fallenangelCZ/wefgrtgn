﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class QuestDefinitionModule
    {
        public static short ID = 27154;

        public const short b1 = 1;
        public const short b2 = 2;
        public const short b3 = 0;

        public short bilinmeyen = 0;
        public int id = 0;
        public QuestCaseModule rootCase;
        public List<LootModule> rewards;
        public List<QuestTypeModule> types;
        public List<QuestIconModule> icons;

        public QuestDefinitionModule(short bilinmeyen, int id, QuestCaseModule rootCase, List<LootModule> rewards, List<QuestTypeModule> types, List<QuestIconModule> icons)
        {
            this.bilinmeyen = bilinmeyen;
            this.id = id;
            this.rootCase = rootCase;
            this.rewards = rewards;
            this.types = types;
            this.icons = icons;
        }

        public static byte[] write(short bilinmeyen, int id, QuestCaseModule rootCase, List<LootModule> rewards, List<QuestTypeModule> types, List<QuestIconModule> icons)
        {
            ByteArray param1 = new ByteArray(ID);

            param1.writeShort(bilinmeyen);

            param1.writeInt(id >> 4 | id << 28);

            QuestCaseModule.write(rootCase.id, rootCase.active, rootCase.mandatory, rootCase.ordered, rootCase.mandatoryCount, rootCase.modifier);

            param1.writeInt(rewards.Count);
            
            foreach (LootModule reward in rewards)
            {
                LootModule.write(reward.lootId, reward.amount);
            }

            param1.writeInt(types.Count());

            foreach (var item in types)
            {
                QuestTypeModule.write(item.type);   
            }

            param1.writeInt(icons.Count());

            foreach (var icon in icons)
            {
                QuestIconModule.write(icon.icon);
            }

            param1.writeShort(-5789);

            Console.WriteLine("ok2");

            return param1.ToByteArray();
        }
    }
}
