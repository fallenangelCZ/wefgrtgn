﻿using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.commands
{
    internal class QuestInitializationCommand
    {
        public static short ID = 7727;
        public QuestDefinitionModule quest;

        public QuestInitializationCommand(QuestDefinitionModule param1)
        {
            this.quest = param1;
        }

        public static byte[] write(QuestDefinitionModule quest)
        {
            ByteArray param1 = new ByteArray(ID);

            QuestDefinitionModule.write(quest.bilinmeyen, quest.id, quest.rootCase, quest.rewards, quest.types, quest.icons);

            Console.WriteLine("ok");

            return param1.ToByteArray();
        }
    }
}
