﻿using Ow.Game.Objects.Stations;
using Ow.Game;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ow.Utils;

namespace Ow.Net.netty.handlers
{
    class QuestsHandler : IHandler
    {
        public void execute(GameSession gameSession, byte[] bytes)
        {
            var player = gameSession.Player;

            var parser = new ByteParser(bytes);

            Console.WriteLine(parser.readUTF());
        }
    }
}
