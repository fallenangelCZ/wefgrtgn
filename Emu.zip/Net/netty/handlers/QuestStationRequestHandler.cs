﻿using Ow.Game.Objects.Stations;
using Ow.Game;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Net.netty.handlers
{
    internal class QuestStationRequestHandler : IHandler
    {
        public void execute(GameSession gameSession, byte[] bytes)
        {
            var player = gameSession.Player;
            Console.WriteLine(3);
            foreach (var station in player.Spacemap.Activatables.Values)
            {
                var inRangeStations = player.Storage.InRangeAssets;
                Console.WriteLine(2);
                if (inRangeStations.ContainsKey(station.Id)) continue;

                if (station is QuestGiverStation)
                    Console.WriteLine(1);
                    station.Click(gameSession);
            }
        }
    }
}
