﻿namespace MySQLManager.Database
{
    public enum DatabaseType
    {
        MySql,
        Mssql
    }
}