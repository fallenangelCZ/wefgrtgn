﻿using Ow.Game.Movements;
using Ow.Net.netty.commands;
using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Game.Objects.Collectables
{
    class IceBox : Collectable
    {
        public IceBox(Position position, Spacemap spacemap, bool respawnable, Player toPlayer = null) : base(AssetTypeModule.BOXTYPE_PIRATE_BOOTY, position, spacemap, respawnable, toPlayer) { }

        public override void Reward(Player player)
        {
            int experience = 0;
            int honor = 0;
            int uridium = 0;
            int credits = 0;

            experience = player.Ship.GetExperienceBoost(Randoms.random.Next(2500, 12800));
            honor = player.Ship.GetHonorBoost(Randoms.random.Next(100, 520));
            uridium = Randoms.random.Next(10000, 30500);
            credits = Randoms.random.Next(100, 7500);

            player.ChangeData(DataType.EXPERIENCE, experience);
            player.ChangeData(DataType.HONOR, honor);
            player.ChangeData(DataType.URIDIUM, uridium);
            player.ChangeData(DataType.CREDITS, credits);

        }

        public override byte[] GetCollectableCreateCommand()
        {
            return CreateBoxCommand.write("TREASURE", Hash, Position.Y, Position.X);
        }
    }
}
