﻿using Ow.Game.Objects;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Game.GalaxyGates.DeltaGate
{
    class DeltaNpcs
    {
        public static readonly List<String> STAGE_1_NPCS = new List<String>()
        {
            { "71:10" }
        };
        //public readonly List<DeltaNpcs> STAGE_2_NPCS;
        //public readonly List<DeltaNpcs> STAGE_3_NPCS;
        //public readonly List<DeltaNpcs> STAGE_4_NPCS;
        //public readonly List<DeltaNpcs> STAGE_5_NPCS;
        //public readonly List<DeltaNpcs> STAGE_6_NPCS;
    }
}
