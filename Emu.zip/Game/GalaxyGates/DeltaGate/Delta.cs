﻿using Ow.Game.GalaxyGates.DeltaGate;
using Ow.Game.Movements;
using Ow.Game.Objects;
using Ow.Game.Objects.AI;
using Ow.Managers;
using Ow.Net.netty.commands;
using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Game.GalaxyGates
{
    class Delta
    {
        public int Wave = 0;
        public int Lives = 10;
        public int enemyCount = 0;
        public int Stage = 0;
        public readonly int gateMapId;
        public readonly Player currentPlayer;
        private readonly GameSession currentGameSession;
        public Portal joinPortal { get; set; }
        private Portal leavePortal;
        private Portal nextStagePortal;
        private DeltaNpcManager npcManager;
        private bool onPosition = false;
        

        public Delta(int wave = 0, int lives = 10, int enemyCount = 0, int stage = 0, int gateMapId = 0, Player currentPlayer = null, GameSession currentGameSession = null)
        {
            Wave = wave;
            Lives = lives;
            this.enemyCount = enemyCount;
            this.gateMapId = gateMapId;
            this.currentPlayer = currentPlayer;
            this.currentGameSession = currentGameSession;
            Stage = stage;
            npcManager = new DeltaNpcManager(stage, currentPlayer, currentGameSession, gateMapId);
        }



        private async void checkMap()
        {
            while(true)
            {
                bool running = false;
                if(currentPlayer != null)
                {
                    if(currentPlayer.Spacemap.Id == 55 && !onPosition)
                    {
                        if(!running)
                        {
                            Start();
                            running = true;
                            onPosition = true;
                        }
                    } else
                    {
                        running = false;
                        onPosition = false;
                        Stop();
                    }
                }
                await Task.Delay(1000);
            }
        }

        public void Start()
        {
            currentPlayer.SendPacket($"0|A|STD|{{{Lives}}} lives left");
            currentPlayer.SendPacket($"0|A|STD|To leave the gate type /leave in the chat");
            currentPlayer.CpuManager.DisableCloak();

            Console.WriteLine(Stage);

            npcManager.SpawnStage();
            

            //currentPlayer.Jump(gateMapId, new Movements.Position(0,0));
        }


        public void spawnWave()
        {
            var npc = new Npc(Randoms.CreateRandomID(), GameManager.GetShip(79), GameManager.GetSpacemap(55), new Position(0, 0), 0);
            //npc.AddVisualModifier(VisualModifierCommand.INVINCIBILITY, 0, "", 0, true);
            npc.AddShield();
        }

        public void Stop() { 

            npcManager.DestroyAll();
        }

        public void CreateJoinPortal()
        {
            var spaceMapId = currentPlayer.Spacemap.Id;
            var targetPositionX = 100;
            var targetPositionY = 100;
            var targetSpaceMap = 55;
            var graphId = 5;
            var factionId = 0;

            joinPortal = new Portal(GameManager.GetSpacemap(spaceMapId), currentPlayer.Position, new Position(targetPositionX, targetPositionY), targetSpaceMap, graphId, factionId, true, true);

            currentPlayer.SendCommand(joinPortal.GetAssetCreateCommand());

            //checkMap();
        }

        public void DeletePortal()
        {
            joinPortal.Remove();
            CreateEscapePortal();
        }

        private void CreateMap()
        {

        }

        private void CreateEscapePortal()
        {
            var spaceMapId = currentPlayer.Spacemap.Id;
            var targetPositionX = currentPlayer.GetBasePosition().X;
            var targetPositionY = currentPlayer.GetBasePosition().Y;
            var targetSpaceMap = currentPlayer.GetBaseMapId();
            var graphId = 1;
            var factionId = 0;

            leavePortal = new Portal(GameManager.GetSpacemap(spaceMapId), currentPlayer.Position, new Position(targetPositionX, targetPositionY), targetSpaceMap, graphId, factionId, true, true);

            GameManager.SendCommandToMap(leavePortal.Spacemap.Id, leavePortal.GetAssetCreateCommand());
        }
    }
}
