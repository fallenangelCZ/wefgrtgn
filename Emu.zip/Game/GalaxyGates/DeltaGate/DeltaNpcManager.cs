﻿using Ow.Game.Movements;
using Ow.Game.Objects;
using Ow.Game.Objects.AI;
using Ow.Game.Objects.Players.Managers;
using Ow.Managers;
using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Game.GalaxyGates.DeltaGate
{
    class DeltaNpcManager
    {
        public int Stage { get; set; }
        private Player currentPlayer;
        private GameSession currentGameSession;
        private int currentMapId;

        private List<Npc> currentNpcs;

        public DeltaNpcManager(int stage, Player currentPlayer, GameSession currentGameSession, int currentMapId)
        {
            Stage = stage;
            this.currentPlayer = currentPlayer;
            this.currentGameSession = currentGameSession;
            this.currentMapId = currentMapId;

            currentNpcs = new List<Npc>();
        }

        public async void SpawnStage()
        {
            switch(Stage)
            {
                case 1:
                    if(currentNpcs.Count == 0) {
                        foreach (var item in DeltaNpcs.STAGE_1_NPCS)
                        {
                            var data = item.Split(':');

                            int shipId = int.Parse(data[0]);
                            int howMany = Int32.Parse(data[1]);

                            SpawnWaves(shipId, howMany);
                            await Task.Delay(3000);
                        }
                    }
                    break;
            }
        }

        private void SpawnWaves(int shipId, int count)
        {
            currentPlayer.SendPacket($"0|A|STD|Spawned new Mobs");
            for (int i = 1; i < count; i++)
            {
                var npc = new Npc(Randoms.CreateRandomID(), GameManager.GetShip(shipId), GameManager.GetSpacemap(currentMapId), Position.GetPosOnCircle(new Position(1600, 1600), 100), 0);
                npc.Damage = npc.Damage * 2;
                npc.MaxHitPoints = npc.MaxHitPoints * 2;
                npc.CurrentHitPoints = npc.CurrentHitPoints * 2;
                npc.MaxShieldPoints = npc.MaxShieldPoints * 2;
                npc.CurrentShieldPoints = npc.CurrentShieldPoints * 2;

                npc.ReceiveAttack(currentPlayer);
                Movement.Move(npc, Position.GetPosOnCircle(currentPlayer.Position, NpcAI.ALIEN_DISTANCE_TO_USER));
                currentNpcs.Add(npc);
                
                //npc.AddShield();
            }
        }

        private void SpawnBoss(int shipId, int howMany, bool isShielded, int minionsShipId, int howManyMinions)
        {

        }

        public void DestroyAll()
        {
            foreach (var item in currentNpcs)
            {
                item.Destroy(item, DestructionType.PLAYER);
            }
            currentNpcs.Clear();
        }

    }
}
