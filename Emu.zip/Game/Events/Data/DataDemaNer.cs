﻿using Ow.Game.Objects;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ow.Game.Events.Data
{
    class DataDemaNer
    {

        public List<Npc> minions { get; set; }
        public ConcurrentDictionary<int, Player> Players { get; set; }

        public DataDemaNer()
        {
            minions = new List<Npc>();
            Players = new ConcurrentDictionary<int, Player>();
        }
    }
}
