﻿using Ow.Game.Events.Data;
using Ow.Game.Movements;
using Ow.Game.Objects.Collectables;
using Ow.Game.Objects;
using Ow.Managers.MySQLManager;
using Ow.Managers;
using Ow.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

namespace Ow.Game.Events
{
    class IceMeteorit
    {
        private static Spacemap Spacemap = GameManager.GetSpacemap(200);
        public static Position CurrentPosition = new Position(10300, 6300);
        public static IceMeteoritMother ice_boss = null;
        private static int wait = 1;
        public static bool Active = false;
        public static DataDemaNer data = new DataDemaNer();


        public static Thread iceProcess;
        private static Thread update;
        private static Thread feedback;
        private static int Seconds = 0;

        public static void Start(int seconds)
        {
            if(!Active)
            {
                Seconds = seconds;
                Spacemap = GameManager.GetSpacemap(200);
                Active = true;
                update = new Thread(updater);

                GameManager.SendPacketToAll($"0|n|KSMSG|Meteorit land in map {Spacemap.Name}");

                ice_boss = new IceMeteoritMother(Randoms.CreateRandomID(), GameManager.GetShip(33), Spacemap, CurrentPosition, 103, 25);
                ice_boss.spawn();

                update.Start();
            }
        }



        private static void updater()
        {
            while(Active)
            {
                if(ice_boss != null && ice_boss.Alive)
                {
                    CurrentPosition = ice_boss.Position;
                }

                if(ice_boss != null && !ice_boss.Alive)
                {
                    //new IceBox(Position.Random(Spacemap, ice_boss.Position.X - 1000, ice_boss.Position.X + 1000, ice_boss.Position.Y - 1000, ice_boss.Position.Y + 1000), Spacemap, false);

                    GameManager.SendPacketToAll($"0|n|KSMSG|Meteorit Dead");

                    CurrentPosition = new Position(10300, 6300);

                    Active = false;

                    update.Interrupt();
                }
            }
        }
    }
}

        /*
        public static void Start(int seconds)
        {
            if (!Active)
            {
                Seconds = seconds;
                Spacemap = GameManager.GetSpacemap(200);
                Active = true;
                iceProcess = new Thread(Starting);
                update = new Thread(Loop);
                feedback = new Thread(Feed);
                iceProcess.Start();
            }
        }

        public static void Feed()
        {
            if (Active)
            {
                while (Active)
                {
                    Thread.Sleep(30000);
                    GameManager.SendPacketToAll($"0|n|KSMSG|METEORIT IN MAP {Spacemap.Name} POSITION {ice_boss.Position.X / 100}/{ice_boss.Position.Y / 100}");
                }
            }
        }

        public static void Starting()
        {
            if (Active)
            {
                int seconds = Seconds;
                int k = seconds - 10;
                GameManager.SendPacketToAll($"0|n|KSMSG|Meteorit will land in map {Spacemap.Name} in {seconds} seconds..");
                for (int i = seconds; i > 0; i--)
                {
                    if (i == k)
                    {
                        string packet = $"0|A|STD| [MAP {Spacemap.Name}]METEORIT land in {i} seconds...";

                        GameManager.SendPacketToAll(packet);
                        k += -10;
                    }
                    Thread.Sleep(1000);


                }

                GameManager.SendPacketToAll($"0|n|KSMSG|Meteorit land in map {Spacemap.Name}");
                ice_boss = createNPC(33, 1, Spacemap.Id, CurrentPosition);
                ice_boss.Name = "-=ICE METEORIT MOTHER=.-";
                ice_boss.Ship.Name = "-=ICE METEORIT MOTHER=.-";
                ice_boss.MaxHitPoints = 45000000;
                ice_boss.CurrentHitPoints = 65000000;
                ice_boss.MaxShieldPoints = 5000000;
                ice_boss.CurrentShieldPoints = 65000000;
                update.Start();
                feedback.Start();
                for (int i = wait; i > 0; i--)
                {
                    Thread.Sleep(1000);

                    if (i <= 1 && data.minions.Count <= 25)
                    {
                        createNPC(103, 1, Spacemap.Id, ice_boss.Position);
                        ice_boss.Heal(250000);
                        i = wait + 5;
                    }
                }
            }
        }

        public static Npc createNPC(int npcID, int amount, int SpacemapID, Position position)
        {
            Npc npc = null;
            for (int i = 1; i <= amount; i++)
            {
                npc = new Npc(Randoms.CreateRandomID(), GameManager.GetShip(npcID), GameManager.GetSpacemap(SpacemapID), position, 0);
                if (npcID == 33)
                if (npcID == 103)
                {
                    data.minions.Add(npc);
                }
            }
            return npc;
        }


        public static void Loop()
        {
            while (Active)
            {
                if (data.minions.Count > 0)
                {
                    for (int i = 0; i < data.minions.Count; i++)
                    {
                        if (data.minions[i].Destroyed)
                        {
                            for (int j = 0; j <= 4; j++)
                            {
                                new CargoBox(Position.Random(Spacemap, data.minions[i].Position.X - 200, data.minions[i].Position.X + 200, data.minions[i].Position.Y - 200, data.minions[i].Position.Y + 200), Spacemap, false, false, false);
                                data.minions.Remove(data.minions[i]);
                                break;
                            }
                        }
                        else
                        {
                            Movement.Move(data.minions[i], Position.Random(ice_boss.Spacemap, ice_boss.Position.X - 1300, ice_boss.Position.X + 1300, ice_boss.Position.Y - 1300, ice_boss.Position.Y + 1300));
                        }
                    }
                }

                if (ice_boss != null)
                {
                    if (ice_boss.Destroyed)
                    {
                        for (int i = 0; i <= GameManager.GameSessions.Count + 10; i++)
                        {
                            //new IceBox(Position.Random(Spacemap, demaner.Position.X - 1000, demaner.Position.X + 1000, demaner.Position.Y - 1000, demaner.Position.Y + 1000), Spacemap, false);
                        }

                        ice_boss.Name = "-=: Ice Meteorit :=-";
                        ice_boss.Ship.Name = "-=: Ice Meteorit :=-";

                        sendReward();

                    }
                }
            }
        }

        public static void sendReward()
        {

            wait = 1;

            Active = false;

            foreach (Character item in Spacemap.Characters.Values)
            {
                if (item is Player playerWin)
                {
                    playerWin.ChangeData(DataType.URIDIUM, 50500);
                    playerWin.ChangeData(DataType.EXPERIENCE, 200000);
                    playerWin.ChangeData(DataType.HONOR, 10250);
                    playerWin.ChangeData(DataType.CREDITS, 2000000);
                }
            }

            GameManager.SendPacketToAll($"0|n|KSMSG| ICE METEORIT DESTROYED ");

            iceProcess.Abort();
            update.Abort();
            feedback.Abort();
        }
    }
        */